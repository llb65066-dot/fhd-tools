export type JobStatus="queued"|"processing"|"completed"|"failed";
export type Job={id:string;url:string;status:JobStatus;createdAt:string};
/** نقطة فصل: اربط هنا مزود API خارجي مصرح به، مع إبقاء المفاتيح على الخادم فقط. */
export async function createJob(url:string):Promise<Job>{return{id:crypto.randomUUID(),url,status:"queued",createdAt:new Date().toISOString()};}
