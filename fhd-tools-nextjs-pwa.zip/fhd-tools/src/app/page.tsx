 "use client";
import {useState} from "react";
import {ArrowLeft,Link2,ShieldCheck,Zap} from "lucide-react";
export default function Home(){
 const[url,setUrl]=useState("");const[status,setStatus]=useState("");
 async function submit(){if(!url.trim()){setStatus("أدخل رابطاً صحيحاً أولاً.");return}setStatus("جارٍ التحقق من الرابط...");try{const r=await fetch("/api/jobs",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({url})});const d=await r.json();setStatus(d.message||"تم إرسال الطلب.")}catch{setStatus("تعذر الاتصال بالخدمة. حاول مرة أخرى.")}}
 return <><header className="header"><div className="container nav"><a className="logo" href="/">FHD<span>Tools</span></a><nav className="navlinks"><a href="#tools">الأدوات</a><a href="#how">طريقة الاستخدام</a><a href="#security">الأمان</a></nav></div></header>
 <main><section className="hero container"><div className="badge"><span className="dot"/> الخدمة متاحة الآن</div><h1>أدوات رقمية <span>بسرعة وبساطة</span></h1><p>منصة عربية حديثة لمعالجة الروابط والخدمات الرقمية. واجهة سريعة، متجاوبة، وقابلة للتثبيت كتطبيق على الجوال.</p>
 <div className="card tool" id="tools"><label className="label">الرابط</label><div className="inputrow"><input className="input" dir="ltr" value={url} onChange={e=>setUrl(e.target.value)} placeholder="https://..." aria-label="الرابط"/><button className="btn" onClick={submit}>تنفيذ <ArrowLeft size={18} style={{verticalAlign:"middle"}}/></button></div>{status&&<div className="status">{status}</div>}</div></section>
 <section className="section container" id="how"><h2>مصمم ليكون سريعاً وواضحاً</h2><p>بنية مستقلة تفصل الواجهة عن الـ API حتى تستطيع تطوير الخدمة لاحقاً دون إعادة بناء الموقع.</p><div className="grid">
 <div className="card feature"><div className="icon"><Zap size={22}/></div><h3>أداء سريع</h3><p>Next.js مع واجهة Mobile First وتجربة محسنة للأجهزة المحمولة.</p></div>
 <div className="card feature"><div className="icon"><Link2 size={22}/></div><h3>API مستقل</h3><p>نقطة API منفصلة للطلبات، ويمكن استبدال مزود الخدمة الخلفي لاحقاً.</p></div>
 <div className="card feature" id="security"><div className="icon"><ShieldCheck size={22}/></div><h3>بنية آمنة</h3><p>لا تضع مفاتيح API السرية داخل المتصفح؛ تحفظ الأسرار في متغيرات البيئة.</p></div>
 </div></section><section className="section container"><h2>جاهز كتطبيق PWA</h2><p>أضف الموقع إلى الشاشة الرئيسية من متصفح الهاتف ليظهر كتطبيق مستقل.</p></section></main>
 <footer className="footer"><div className="container footerin"><span>© 2026 FHD Tools</span><span>منصة مستقلة — ليست تابعة لـ Zefoy أو TikTok</span></div></footer></>}
