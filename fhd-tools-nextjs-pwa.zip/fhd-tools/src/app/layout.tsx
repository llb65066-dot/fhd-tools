import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata={title:"FHD Tools",description:"منصة عربية للأدوات الرقمية",manifest:"/manifest.webmanifest",themeColor:"#07090d"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ar" dir="rtl"><body>{children}</body></html>}
